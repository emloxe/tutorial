# 动态使用Icon

```js

import * as Icon from "@ant-design/icons";

let iconName = 'HomeOutlined';


// 如下调用即可
React.createElement(Icon[iconName])

```