import clientAppEnhance0 from 'F:/FE/vuepress3/node_modules/@vuepress/theme-default/lib/client/clientAppEnhance.js'
import clientAppEnhance1 from 'F:/FE/vuepress3/node_modules/@vuepress/plugin-medium-zoom/lib/client/clientAppEnhance.js'
import clientAppEnhance2 from 'F:/FE/vuepress3/node_modules/@vuepress/plugin-theme-data/lib/client/clientAppEnhance.js'

export const clientAppEnhances = [
  clientAppEnhance0,
  clientAppEnhance1,
  clientAppEnhance2,
]
