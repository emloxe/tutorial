export const siteData = {
  "base": "/tutorial/",
  "lang": "en-US",
  "title": "TUTORIAL",
  "description": "W.J. Zhang教程教程网站，张雯瑾教程网站，emloxe",
  "head": [],
  "locales": {}
}
