import clientAppSetup0 from 'F:/FE/vuepress3/node_modules/@vuepress/theme-default/lib/client/clientAppSetup.js'
import clientAppSetup1 from 'F:/FE/vuepress3/node_modules/@vuepress/plugin-active-header-links/lib/client/clientAppSetup.js'
import clientAppSetup2 from 'F:/FE/vuepress3/node_modules/@vuepress/plugin-nprogress/lib/client/clientAppSetup.js'

export const clientAppSetups = [
  clientAppSetup0,
  clientAppSetup1,
  clientAppSetup2,
]
