export const data = {
  "key": "v-22a39d25",
  "path": "/about.html",
  "title": "关于本站",
  "lang": "en-US",
  "frontmatter": {
    "sidebar": false
  },
  "excerpt": "",
  "headers": [],
  "filePathRelative": "about.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
