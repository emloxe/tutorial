export const data = {
  "key": "v-d7e5fe3a",
  "path": "/js/RegExp.html",
  "title": "正则表达式",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "示例",
      "slug": "示例",
      "children": [
        {
          "level": 3,
          "title": "以指定字符结尾",
          "slug": "以指定字符结尾",
          "children": []
        },
        {
          "level": 3,
          "title": "字符串中是否包含指定字符",
          "slug": "字符串中是否包含指定字符",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "js/RegExp.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
