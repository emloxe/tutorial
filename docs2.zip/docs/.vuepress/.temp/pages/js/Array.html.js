export const data = {
  "key": "v-0d47706d",
  "path": "/js/Array.html",
  "title": "数组",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "基本方法",
      "slug": "基本方法",
      "children": [
        {
          "level": 3,
          "title": "遍历",
          "slug": "遍历",
          "children": []
        },
        {
          "level": 3,
          "title": "处理数组",
          "slug": "处理数组",
          "children": []
        },
        {
          "level": 3,
          "title": "过滤",
          "slug": "过滤",
          "children": []
        },
        {
          "level": 3,
          "title": "查询",
          "slug": "查询",
          "children": []
        }
      ]
    },
    {
      "level": 2,
      "title": "具体事例",
      "slug": "具体事例",
      "children": [
        {
          "level": 3,
          "title": "创建指定长度的数组",
          "slug": "创建指定长度的数组",
          "children": []
        },
        {
          "level": 3,
          "title": "生成二维空数组",
          "slug": "生成二维空数组",
          "children": []
        },
        {
          "level": 3,
          "title": "数组合并不去重",
          "slug": "数组合并不去重",
          "children": []
        },
        {
          "level": 3,
          "title": "数组去重合并",
          "slug": "数组去重合并",
          "children": []
        },
        {
          "level": 3,
          "title": "类数组对象转化为真正的JavaScript数组",
          "slug": "类数组对象转化为真正的javascript数组",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "js/Array.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
