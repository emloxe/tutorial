export const data = {
  "key": "v-756cddfe",
  "path": "/js/Date.html",
  "title": "时间",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "时间解析",
      "slug": "时间解析",
      "children": []
    },
    {
      "level": 2,
      "title": "返回成指定格式的字符串",
      "slug": "返回成指定格式的字符串",
      "children": []
    },
    {
      "level": 2,
      "title": "其他",
      "slug": "其他",
      "children": [
        {
          "level": 3,
          "title": "获取当前月有多少天",
          "slug": "获取当前月有多少天",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "js/Date.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
