export const data = {
  "key": "v-5249d24a",
  "path": "/js/util.html",
  "title": "工具类",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "类型监测",
      "slug": "类型监测",
      "children": []
    },
    {
      "level": 2,
      "title": "生成随机序列",
      "slug": "生成随机序列",
      "children": []
    }
  ],
  "filePathRelative": "js/util.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
