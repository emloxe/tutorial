export const data = {
  "key": "v-ecd14a2a",
  "path": "/js/upload.html",
  "title": "上传文件",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "创建弹框读取文件",
      "slug": "创建弹框读取文件",
      "children": []
    },
    {
      "level": 2,
      "title": "文件客户端读取",
      "slug": "文件客户端读取",
      "children": []
    },
    {
      "level": 2,
      "title": "上传到服务器",
      "slug": "上传到服务器",
      "children": []
    }
  ],
  "filePathRelative": "js/upload.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
