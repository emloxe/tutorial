export const data = {
  "key": "v-46f50841",
  "path": "/vue/%E5%A4%9A%E9%A1%B5%E9%9D%A2%E5%85%A5%E5%8F%A3.html",
  "title": "多页面入口",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "vue/多页面入口.md",
  "git": {}
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
