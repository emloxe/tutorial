export const data = {
  "key": "v-3f07be76",
  "path": "/vue/vuex.html",
  "title": "vuex",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "调用",
      "slug": "调用",
      "children": []
    },
    {
      "level": 2,
      "title": "参考文档",
      "slug": "参考文档",
      "children": []
    }
  ],
  "filePathRelative": "vue/vuex.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
