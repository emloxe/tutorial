export const data = {
  "key": "v-f5813ea6",
  "path": "/react/%E8%B7%AF%E7%94%B1.html",
  "title": "路由",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "第一层路由",
      "slug": "第一层路由",
      "children": []
    },
    {
      "level": 2,
      "title": "子层路由",
      "slug": "子层路由",
      "children": []
    },
    {
      "level": 2,
      "title": "最新文档地址",
      "slug": "最新文档地址",
      "children": []
    }
  ],
  "filePathRelative": "react/路由.md",
  "git": {}
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
