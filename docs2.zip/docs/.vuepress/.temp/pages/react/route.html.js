export const data = {
  "key": "v-26b4508e",
  "path": "/react/route.html",
  "title": "路由",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "第一层路由",
      "slug": "第一层路由",
      "children": []
    },
    {
      "level": 2,
      "title": "子层路由",
      "slug": "子层路由",
      "children": []
    },
    {
      "level": 2,
      "title": "最新文档地址",
      "slug": "最新文档地址",
      "children": []
    }
  ],
  "filePathRelative": "react/route.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
