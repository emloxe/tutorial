export const data = {
  "key": "v-db1c9e26",
  "path": "/react/hook.html",
  "title": "hook",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "参考文档",
      "slug": "参考文档",
      "children": []
    }
  ],
  "filePathRelative": "react/hook.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
