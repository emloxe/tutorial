<template><p>查询真实IP
通过IPAddress.com首页,输入raw.githubusercontent.com查询到真实IP地址</p>
<p>windows
C:\Windows\System32\drivers\etc\hosts 添加</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>199.232.4.133 raw.githubusercontent.com 
</code></pre><div class="line-numbers"><span class="line-number">1</span><br></div></div><p>CentOS及macOS直接在终端输入</p>
<p>sudo vi /etc/hosts
添加以下内容保存即可</p>
<div class="language-text ext-text line-numbers-mode"><pre v-pre class="language-text"><code>199.232.4.133 raw.githubusercontent.com
</code></pre><div class="line-numbers"><span class="line-number">1</span><br></div></div></template>
