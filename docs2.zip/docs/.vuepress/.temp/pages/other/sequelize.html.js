export const data = {
  "key": "v-0a2c637a",
  "path": "/other/sequelize.html",
  "title": "sequelize",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "文档",
      "slug": "文档",
      "children": []
    },
    {
      "level": 2,
      "title": "遇到的问题",
      "slug": "遇到的问题",
      "children": []
    }
  ],
  "filePathRelative": "other/sequelize.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
