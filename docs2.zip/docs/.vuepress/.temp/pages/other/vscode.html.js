export const data = {
  "key": "v-1f997697",
  "path": "/other/vscode.html",
  "title": "vscode",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "格式化代码时，没有根据eslint格式",
      "slug": "格式化代码时-没有根据eslint格式",
      "children": []
    },
    {
      "level": 2,
      "title": "出现的问题",
      "slug": "出现的问题",
      "children": []
    }
  ],
  "filePathRelative": "other/vscode.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
