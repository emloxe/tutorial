export const data = {
  "key": "v-9646910a",
  "path": "/other/axios.html",
  "title": "axios",
  "lang": "en-US",
  "frontmatter": {
    "sidebar": "auto"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "请求方法",
      "slug": "请求方法",
      "children": []
    }
  ],
  "filePathRelative": "other/axios.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
