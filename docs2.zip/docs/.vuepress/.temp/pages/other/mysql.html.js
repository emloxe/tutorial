export const data = {
  "key": "v-2938becf",
  "path": "/other/mysql.html",
  "title": "mysql",
  "lang": "en-US",
  "frontmatter": {
    "sidebar": "auto"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "基础操作",
      "slug": "基础操作",
      "children": []
    },
    {
      "level": 2,
      "title": "数据导入导出",
      "slug": "数据导入导出",
      "children": [
        {
          "level": 3,
          "title": "导出",
          "slug": "导出",
          "children": []
        },
        {
          "level": 3,
          "title": "导入",
          "slug": "导入",
          "children": []
        }
      ]
    }
  ],
  "filePathRelative": "other/mysql.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
