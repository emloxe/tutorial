export const data = {
  "key": "v-0bcd0886",
  "path": "/other/yarn.html",
  "title": "yarn",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "基础使用",
      "slug": "基础使用",
      "children": []
    }
  ],
  "filePathRelative": "other/yarn.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
