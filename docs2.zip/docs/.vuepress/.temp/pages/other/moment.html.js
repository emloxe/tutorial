export const data = {
  "key": "v-0e3dfefe",
  "path": "/other/moment.html",
  "title": "moment",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "other/moment.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
