export const data = {
  "key": "v-450efb70",
  "path": "/DataStructures&Algorithms/",
  "title": "前言",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "DataStructures&Algorithms/README.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
