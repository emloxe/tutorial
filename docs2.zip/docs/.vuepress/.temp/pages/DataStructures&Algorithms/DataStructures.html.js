export const data = {
  "key": "v-1bec2b07",
  "path": "/DataStructures&Algorithms/DataStructures.html",
  "title": "数据结构",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "filePathRelative": "DataStructures&Algorithms/DataStructures.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
