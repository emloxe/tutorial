export const data = {
  "key": "v-7398a69a",
  "path": "/DataStructures&Algorithms/sort.html",
  "title": "排序",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "快速排序",
      "slug": "快速排序",
      "children": []
    }
  ],
  "filePathRelative": "DataStructures&Algorithms/sort.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
