export const data = {
  "key": "v-0801f6cd",
  "path": "/mysql/%E6%95%B0%E6%8D%AE.html",
  "title": "数据操作",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "数据导入",
      "slug": "数据导入",
      "children": []
    },
    {
      "level": 2,
      "title": "数据导出",
      "slug": "数据导出",
      "children": []
    }
  ],
  "filePathRelative": "mysql/数据.md",
  "git": {}
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
