export const data = {
  "key": "v-0f5e6bae",
  "path": "/mysql/data.html",
  "title": "数据操作",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "数据导入",
      "slug": "数据导入",
      "children": []
    },
    {
      "level": 2,
      "title": "数据导出",
      "slug": "数据导出",
      "children": []
    }
  ],
  "filePathRelative": "mysql/data.md",
  "git": {
    "updatedTime": 1638161516000,
    "contributors": [
      {
        "name": "ZWJ",
        "email": "qwrtyp@live.cn",
        "commits": 1
      }
    ]
  }
}
